// raylite-Demo-Plugin: „gh <Suchbegriff>“ → GitHub-Repository-Suche im Browser.
// Aufrufvertrag: siehe ../README.md

const query = (process.argv[2] ?? "").trim();
const url = `https://github.com/search?q=${encodeURIComponent(query)}&type=repositories`;

process.stdout.write(
  JSON.stringify({
    title: `GitHub-Repos suchen: ${query}`,
    subtitle: "github.com · öffnet im Browser",
    action: "shell_open",
    payload: url,
  }),
);
